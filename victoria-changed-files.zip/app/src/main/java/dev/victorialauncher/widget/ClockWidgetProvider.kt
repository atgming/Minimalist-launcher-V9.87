// SPDX-License-Identifier: GPL-3.0-or-later
package dev.victorialauncher.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.Settings
import android.util.TypedValue
import android.view.View
import android.widget.RemoteViews
import dev.victorialauncher.R
import dev.victorialauncher.media.NotificationCountBus

/**
 * A clock and date, so a fresh launcher has something on it without hunting for a widget that
 * suits it.
 *
 * The views tick by themselves — TextClock runs inside whichever host draws it and follows the
 * system's 12- or 24-hour setting — so this provider is only ever asked to say where a tap
 * goes. There is no update interval and nothing is scheduled.
 */
class ClockWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { render(context, manager, it) }
    }

    /** Settings belong to one widget, so each is drawn from its own. */
    override fun onDeleted(context: Context, ids: IntArray) {
        ids.forEach { ClockWidgetConfig.forget(context, it) }
        syncWeatherReceiver(context)
    }

    companion object {
        fun componentName(context: Context) =
            ComponentName(context, ClockWidgetProvider::class.java)

        /**
         * Leaves the weather receiver enabled only while some widget still shows weather.
         *
         * Asked after anything that can change the answer, rather than tracked: the widgets are
         * the only record of what is wanted, and reading all of them is cheaper than keeping a
         * count correct across a process that gets killed.
         */
        /** Redraws every clock widget, for the things that change without being asked about. */
        fun renderAll(context: Context) {
            runCatching {
                val manager = AppWidgetManager.getInstance(context)
                manager.getAppWidgetIds(componentName(context))
                    ?.forEach { render(context, manager, it) }
            }
        }

        fun syncWeatherReceiver(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val wanted = runCatching {
                manager.getAppWidgetIds(componentName(context))
                    ?.any { ClockWidgetConfig.read(context, it).showWeather } == true
            }.getOrDefault(false)
            ClockWidgetWeather.setReceiverEnabled(context, wanted)
        }

        /**
         * Draws one widget as its own settings ask.
         *
         * Forcing 12 or 24 hours means giving TextClock the same pattern for both, since it
         * picks between them by the system setting and would otherwise ignore the choice.
         *
         * The request codes carry the widget id, or two clocks would share one PendingIntent
         * and the second would silently take the first's target. Three per widget, one for each
         * row that can be tapped.
         */
        private const val HOUR_ACCENT = 0xFFE9C46A.toInt()

        fun render(context: Context, manager: AppWidgetManager, widgetId: Int) {
            val config = ClockWidgetConfig.read(context, widgetId)
            val twelve = "h"
            val twentyFour = "HH"
            val density = context.resources.displayMetrics.density
            fun gap(dp: Int) = (dp * density).toInt()
            val views = RemoteViews(context.packageName, R.layout.widget_clock).apply {
                setViewPadding(R.id.widget_date, 0, gap(config.dateGapDp), 0, 0)
                setViewPadding(R.id.widget_weather, 0, gap(config.weatherGapDp), 0, 0)
                setViewPadding(R.id.widget_notifications, 0, gap(config.notificationsGapDp), 0, 0)
                setViewPadding(R.id.widget_battery, 0, gap(config.batteryGapDp), 0, 0)
                when (config.hourFormat) {
                    ClockWidgetConfig.HourFormat.SYSTEM -> {
                        setCharSequence(R.id.widget_time, "setFormat12Hour", twelve)
                        setCharSequence(R.id.widget_time, "setFormat24Hour", twentyFour)
                    }
                    ClockWidgetConfig.HourFormat.TWELVE -> {
                        setCharSequence(R.id.widget_time, "setFormat12Hour", twelve)
                        setCharSequence(R.id.widget_time, "setFormat24Hour", twelve)
                    }
                    ClockWidgetConfig.HourFormat.TWENTY_FOUR -> {
                        setCharSequence(R.id.widget_time, "setFormat12Hour", twentyFour)
                        setCharSequence(R.id.widget_time, "setFormat24Hour", twentyFour)
                    }
                }
                setTextViewTextSize(R.id.widget_time, TypedValue.COMPLEX_UNIT_SP, config.timeSizeSp.toFloat())
                // Gold hours, white minutes. The accent is fixed for now; minutes follow the user's color.
                setTextColor(R.id.widget_time, HOUR_ACCENT)
                setTextViewTextSize(R.id.widget_time_min, TypedValue.COMPLEX_UNIT_SP, config.timeSizeSp.toFloat())
                setTextColor(R.id.widget_time_min, config.colorAt(config.timeOpacity))

                val date = config.datePattern
                if (date == null) {
                    setViewVisibility(R.id.widget_date, View.GONE)
                } else {
                    setViewVisibility(R.id.widget_date, View.VISIBLE)
                    setCharSequence(R.id.widget_date, "setFormat12Hour", date)
                    setCharSequence(R.id.widget_date, "setFormat24Hour", date)
                    setTextViewTextSize(R.id.widget_date, TypedValue.COMPLEX_UNIT_SP, config.dateSizeSp.toFloat())
                    setTextColor(R.id.widget_date, config.colorAt(config.dateOpacity))
                }

                // Read on each draw rather than followed: a RemoteViews can be told to keep up
                // with the clock, but there is no such thing for the battery.
                val battery = if (config.showBattery) ClockWidgetBattery.percent(context) else null
                if (battery == null) {
                    setViewVisibility(R.id.widget_battery, View.GONE)
                } else {
                    setViewVisibility(R.id.widget_battery, View.VISIBLE)
                    setTextViewText(R.id.widget_battery, context.getString(R.string.widget_clock_battery_percent, battery))
                    setTextViewTextSize(R.id.widget_battery, TypedValue.COMPLEX_UNIT_SP, config.batterySizeSp.toFloat())
                    setTextColor(R.id.widget_battery, config.colorAt(config.batteryOpacity))
                }

                // Whatever another app last told us, if it is recent enough to still be true.
                val weather = if (config.showWeather) ClockWidgetWeather.current(context) else null
                if (weather == null) {
                    setViewVisibility(R.id.widget_weather, View.GONE)
                } else {
                    setViewVisibility(R.id.widget_weather, View.VISIBLE)
                    setTextViewText(
                        R.id.widget_weather,
                        ClockWidgetWeather.formatted(weather, config.weatherFahrenheit),
                    )
                    setTextViewTextSize(R.id.widget_weather, TypedValue.COMPLEX_UNIT_SP, config.weatherSizeSp.toFloat())
                    setTextColor(R.id.widget_weather, config.colorAt(config.weatherOpacity))
                }

                // A count and nothing else, for the same reason the badges carry no text: what
                // a notification says is its own business and not the home screen's.
                val notifications = if (config.showNotifications) {
                    NotificationCountBus.counts.value.values.sum().takeIf { it > 0 }
                } else {
                    null
                }
                if (notifications == null) {
                    setViewVisibility(R.id.widget_notifications, View.GONE)
                } else {
                    setViewVisibility(R.id.widget_notifications, View.VISIBLE)
                    setTextViewText(
                        R.id.widget_notifications,
                        context.resources.getQuantityString(
                            R.plurals.widget_clock_notification_count,
                            notifications,
                            notifications,
                        ),
                    )
                    setTextViewTextSize(R.id.widget_notifications, TypedValue.COMPLEX_UNIT_SP, config.notificationsSizeSp.toFloat())
                    setTextColor(R.id.widget_notifications, config.colorAt(config.notificationsOpacity))
                }

                // What is coming up. The event rows are a fixed three in the layout rather
                // than a list, because a RemoteViews cannot be given children it was not
                // written with — so the unused ones are simply hidden.
                val events = if (config.showAgenda) {
                    ClockWidgetAgenda.events(
                        context,
                        limit = config.agendaCount,
                        lookaheadHours = config.agendaLookaheadHours,
                        relative = config.agendaRelative,
                    )
                } else {
                    emptyList()
                }
                EVENT_ROWS.forEachIndexed { index, viewId ->
                    val entry = events.getOrNull(index)
                    if (entry == null) {
                        setViewVisibility(viewId, View.GONE)
                    } else {
                        setViewVisibility(viewId, View.VISIBLE)
                        setTextViewText(viewId, entry.text)
                        setTextViewTextSize(viewId, TypedValue.COMPLEX_UNIT_SP, config.agendaSizeSp.toFloat())
                        setTextColor(viewId, config.colorAt(config.agendaOpacity))
                        setOnClickPendingIntent(
                            viewId,
                            open(context, calendarIntent(), widgetId * 8 + 4 + index),
                        )
                    }
                }

                val alarm = if (config.showAlarm) ClockWidgetAgenda.nextAlarm(context) else null
                // Above the group rather than every row in it: the events read as one list.
                val agendaRows = EVENT_ROWS.toList() + R.id.widget_alarm
                val firstAgendaRow = if (events.isNotEmpty()) R.id.widget_event_1 else R.id.widget_alarm
                agendaRows.forEach { viewId ->
                    setViewPadding(viewId, 0, if (viewId == firstAgendaRow) gap(config.agendaGapDp) else 0, 0, 0)
                }
                if (alarm == null) {
                    setViewVisibility(R.id.widget_alarm, View.GONE)
                } else {
                    setViewVisibility(R.id.widget_alarm, View.VISIBLE)
                    setTextViewText(R.id.widget_alarm, alarm.text)
                    setTextViewTextSize(R.id.widget_alarm, TypedValue.COMPLEX_UNIT_SP, config.agendaSizeSp.toFloat())
                    setTextColor(R.id.widget_alarm, config.colorAt(config.agendaOpacity))
                    setOnClickPendingIntent(
                        R.id.widget_alarm,
                        open(context, clockIntent(context), widgetId * 8 + 7),
                    )
                }

                setOnClickPendingIntent(R.id.widget_time, open(context, clockIntent(context), widgetId * 3))
                setOnClickPendingIntent(R.id.widget_time_min, open(context, clockIntent(context), widgetId * 3))
                setOnClickPendingIntent(R.id.widget_date, open(context, calendarIntent(), widgetId * 3 + 1))
                setOnClickPendingIntent(R.id.widget_battery, open(context, batteryIntent(context), widgetId * 3 + 2))
                // Only where there is somewhere to go. A row that looks tappable and does
                // nothing is worse than one that plainly is not.
                val weatherTarget = config.weatherPackage?.let { launchIntentFor(context, it) }
                setOnClickPendingIntent(
                    R.id.widget_weather,
                    weatherTarget?.let { open(context, it, widgetId * 4 + 3) },
                )
            }
            manager.updateAppWidget(widgetId, views)
        }

        private fun open(context: Context, intent: Intent, requestCode: Int): PendingIntent? =
            runCatching {
                PendingIntent.getActivity(
                    context,
                    requestCode,
                    intent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
                )
            }.getOrNull()

        private val EVENT_ROWS = intArrayOf(R.id.widget_event_1, R.id.widget_event_2, R.id.widget_event_3)

        private fun launchIntentFor(context: Context, pkg: String): Intent? = runCatching {
            context.packageManager.getLaunchIntentForPackage(pkg)
                ?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }.getOrNull()

        private fun clockIntent(context: Context): Intent {
            val showAlarms = Intent(AlarmClock.ACTION_SHOW_ALARMS)
            val handler = runCatching {
                context.packageManager.resolveActivity(showAlarms, 0)
            }.getOrNull()?.activityInfo
            if (handler != null && handler.exported) {
                return showAlarms
                    .setClassName(handler.packageName, handler.name)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            val launch = handler?.packageName
                ?.let { runCatching { context.packageManager.getLaunchIntentForPackage(it) }.getOrNull() }
            return (launch ?: showAlarms).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        /**
         * Battery settings, or the settings app if this device has no such screen. A
         * PendingIntent aimed at nothing fails silently at the tap, which reads as a dead
         * widget rather than as a missing screen.
         */
        private fun batteryIntent(context: Context): Intent {
            val usage = Intent(Intent.ACTION_POWER_USAGE_SUMMARY)
            val resolved = runCatching {
                context.packageManager.resolveActivity(usage, 0)
            }.getOrNull() != null
            return (if (resolved) usage else Intent(Settings.ACTION_SETTINGS))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        private fun calendarIntent() = Intent(Intent.ACTION_VIEW)
            .setData(CalendarContract.CONTENT_URI.buildUpon().appendPath("time").build())
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }
}
