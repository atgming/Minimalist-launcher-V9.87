// SPDX-License-Identifier: GPL-3.0-or-later
package dev.victorialauncher.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.core.handlers.ReplaceFileCorruptionHandler
import androidx.datastore.preferences.core.PreferenceDataStoreFactory
import androidx.datastore.preferences.core.MutablePreferences
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStoreFile
import dev.victorialauncher.ui.theme.DEFAULT_SHADOW_STRENGTH
import dev.victorialauncher.ui.theme.SHADOW_STRENGTH_RANGE
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import androidx.datastore.preferences.core.longPreferencesKey
import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject

enum class EdgeSide { LEFT, RIGHT, BOTH }

/** How the A-Z strip moves under a fingertip. */
enum class ScrubStyle { BELL, RIPPLE }

/** The bubble that shows the letter under a finger on the A-Z strip, or none at all. */
enum class ScrubBubbleShape { ROUNDED, CIRCLE, SQUARE, HIDDEN }

/**
 * Tunables for the ripple strip's wave simulation.
 *
 * @property speed how fast ripples travel along the strip, in letters per second
 * @property damping how quickly they die out (1/s); low values ring for longer
 * @property stiffness how hard the strip is pulled toward the bell under the finger; low
 *   values lag and wobble, high values track tightly
 */
data class RippleParams(
    val speed: Float = 30f,
    val damping: Float = 20f,
    val stiffness: Float = 600f,
) {
    companion object {
        val SPEED_RANGE = 4f..60f
        val DAMPING_RANGE = 0.5f..40f
        val STIFFNESS_RANGE = 5f..1200f
    }
}

/**
 * Which way an app row is swiped to reach the shortcuts it publishes.
 *
 * A direction and not a switch because only one of the two does anything, and which one should
 * be the useful one is a question about the hand holding the phone.
 */
enum class ShortcutSwipe { OFF, RIGHT, LEFT }

/** Which edge favorites and app rows line up against. */
enum class HomeAlignment { LEFT, CENTER, RIGHT }

/** Which side of an app's name its icon sits on. */
enum class IconSide { LEFT, RIGHT }

/** The two swipe directions under the favorites that can launch an app. */
enum class QuickLaunchSlot { LEFT, RIGHT }

/** Which edge an app is carried in from when it is opened by a sideways swipe. */

/**
 * Where the favorites section gets its apps.
 *
 * FREQUENT is the same section drawn from what has actually been opened, so everything that
 * renders a favorite renders one of these too — it is the list that is computed, not the row.
 */
enum class FavoritesSource { MANUAL, FREQUENT }

/** Enough to be a shortlist, not so many that the section becomes the app list again. */
val FREQUENT_RANGE = 3..12

/**
 * How far down the viewport a scrubbed letter may be parked.
 *
 * Nearly the whole screen. The top is the top, and the only reason to stop short of the
 * bottom is that past this the letter's own row is half off the screen and there is nothing
 * under it to read — which is a broken state rather than a taste anyone holds.
 */
val SECTION_TOP_RANGE = 0..90

/** Rows a second a held letter walks the list at. */
val HOLD_SCROLL_RANGE = 1..12

/** Past about this the strip is being pushed off the edge it belongs to. */
val EDGE_ZONE_INSET_RANGE = 0..32

/** Enough to be a list of what is new, short of being a second app list. */
val RECENT_SECTION_RANGE = 3..15
enum class AppFont { SYSTEM, SANS_SERIF, SERIF, MONOSPACE, CUSTOM }

/** AUTO picks light or dark text from the wallpaper's own colors. */
enum class TextColorMode { AUTO, LIGHT, DARK, MATERIAL, CUSTOM }

/**
 * The mask an icon is drawn through.
 *
 * SYSTEM leaves the drawable alone, which means whatever shape the device already applies.
 * The rest re-mask an adaptive icon's own layers; an icon that is not adaptive has no safe
 * zone to cut into, so it is left as it is whatever this says.
 */
enum class IconShape { SYSTEM, CIRCLE, ROUNDED, SQUARE, TILE }

/** When the A-Z strip shows on the home screen itself. */
enum class AzStripVisibility { NEVER, LANDSCAPE, ALWAYS }

private const val PREFS_NAME = "victoria_prefs"

@Volatile
private var store: DataStore<Preferences>? = null
private val storeLock = Any()

/**
 * The one store for the whole process: two open on the same file is an error.
 *
 * Built by hand rather than through the property delegate because recovering from a damaged
 * file needs to know where the file is, and the delegate's corruption handler is never told.
 * Without one, a file that does not parse throws on every read, which for a home app is a
 * crash at every start and a phone stuck restarting it.
 */
private val Context.dataStore: DataStore<Preferences>
    get() = store ?: synchronized(storeLock) {
        store ?: applicationContext.let { app ->
            val file = app.preferencesDataStoreFile(PREFS_NAME)
            PreferenceDataStoreFactory.create(
                corruptionHandler = ReplaceFileCorruptionHandler { salvagePreferences(file) },
                produceFile = { file },
            )
        }.also { store = it }
    }

/** Bumped only if the shape of an exported file changes, so an old one can be refused. */
private const val EXPORT_FORMAT = 1

/** [json] to write out, and whether anything belonging to the private space was left out of it. */
data class ExportResult(val json: String, val omittedPrivateSpace: Boolean)

class Prefs(private val context: Context) {

    // The settings whose values are app keys take their names from PrivateSpaceExport, which is
    // what has to recognise every one of them by name to keep a locked space out of a backup. A
    // name spelled out in both places is a name that can be changed in one of them.
    private object Keys {
        val HIDDEN_APPS = stringSetPreferencesKey(PREF_HIDDEN_APPS)
        val FREQUENT_EXCLUDED = stringSetPreferencesKey(PREF_FREQUENT_EXCLUDED)
        val FAVORITES = stringPreferencesKey(PREF_FAVORITES)
        val FOLDERS = stringPreferencesKey(PREF_FOLDERS)
        val NAME_OVERRIDES = stringPreferencesKey(PREF_NAME_OVERRIDES)
        val ICON_OVERRIDES = stringPreferencesKey(PREF_ICON_OVERRIDES)
        val ICON_SIZE_DP = intPreferencesKey("icon_size_dp")
        val LABEL_SIZE_SP = intPreferencesKey("label_size_sp")
        val ITEM_SPACING_DP = intPreferencesKey("item_spacing_dp")
        val SIDE_PADDING_DP = intPreferencesKey("side_padding_dp")
        val NOW_PLAYING_HEIGHT_DP = intPreferencesKey("now_playing_height_dp")
        val NOW_PLAYING_PAD_TOP = intPreferencesKey("now_playing_pad_top")
        val NOW_PLAYING_PAD_BOTTOM = intPreferencesKey("now_playing_pad_bottom")
        val WIDGET_PAD_TOP = intPreferencesKey("widget_pad_top")
        val WIDGET_PAD_BOTTOM = intPreferencesKey("widget_pad_bottom")
        val FAVORITES_PAD_TOP = intPreferencesKey("favorites_pad_top")
        val FAVORITES_PAD_BOTTOM = intPreferencesKey("favorites_pad_bottom")
        val FONT = stringPreferencesKey("font")
        val FONT_FILE = stringPreferencesKey("font_file")
        val TEXT_COLOR_CUSTOM = intPreferencesKey("text_color_custom")
        val DIM_COLOR = intPreferencesKey("dim_color")
        val ALLOW_ROTATION = booleanPreferencesKey("allow_rotation")
        val SWIPE_FOR_SHORTCUTS = booleanPreferencesKey("swipe_for_shortcuts")
        val SHORTCUT_SWIPE = stringPreferencesKey("shortcut_swipe")
        val THEMED_ICONS = booleanPreferencesKey("themed_icons")
        val ICON_SHAPE = stringPreferencesKey("icon_shape")
        val HIDE_STATUS_BAR = booleanPreferencesKey("hide_status_bar")
        val HIDE_STATUS_BAR_APPLIST = booleanPreferencesKey("hide_status_bar_applist")
        val DIM_WALLPAPER_ALPHA = floatPreferencesKey("dim_wallpaper_alpha")
        val HAPTICS_ENABLED = booleanPreferencesKey("haptics_enabled")
        val DIM_HOME_ALPHA = floatPreferencesKey("dim_home_alpha")
        val SHOW_FAVORITE_LABELS = booleanPreferencesKey("show_favorite_labels")
        val TEXT_COLOR_MODE = stringPreferencesKey("text_color_mode")
        val DOUBLE_TAP_TO_LOCK = booleanPreferencesKey("double_tap_to_lock")
        val EDGE_SIDE = stringPreferencesKey("edge_side")
        val SCRUB_STYLE = stringPreferencesKey("scrub_style")
        val SCRUB_BUBBLE_SHAPE = stringPreferencesKey("scrub_bubble_shape")
        val RIPPLE_SPEED = floatPreferencesKey("ripple_speed")
        val RIPPLE_DAMPING = floatPreferencesKey("ripple_damping")
        val RIPPLE_STIFFNESS = floatPreferencesKey("ripple_stiffness")
        val ALWAYS_SHOW_AZ = booleanPreferencesKey("always_show_az")
        val AZ_STRIP_VISIBILITY = stringPreferencesKey("az_strip_visibility")
        val SHOW_ALPHABET = booleanPreferencesKey("show_alphabet")
        val ALIGN_RIGHT = booleanPreferencesKey("align_right")
        val ICON_PACK_PACKAGE = stringPreferencesKey("icon_pack_package")
        val NOW_PLAYING_ENABLED = booleanPreferencesKey("now_playing_enabled")
        val WIDGET_ID = intPreferencesKey("widget_id")
        val WIDGET_POSITION = intPreferencesKey("widget_position")
        val WIDGET_HEIGHT_DP = intPreferencesKey("widget_height_dp")
        val WIDGET_IDS = stringPreferencesKey("widget_ids")
        val WIDGETS_STACKED = booleanPreferencesKey("widgets_stacked")
        val WIDGET_HEIGHT_AUTO = booleanPreferencesKey("widget_height_auto")
        val WIDGET_SIDE_PADDING_DP = intPreferencesKey("widget_side_padding_dp")
        val WIDGET_OFFSET_X_DP = intPreferencesKey("widget_offset_x_dp")
        val SWIPE_UP_OPENS_LIST = booleanPreferencesKey("swipe_up_opens_list")
        val APPLIST_SEARCH_ENABLED = booleanPreferencesKey("applist_search_enabled")
        val APPLIST_SEARCH_BOTTOM = booleanPreferencesKey("applist_search_bottom")
        val APPLIST_SEARCH_HIDDEN = booleanPreferencesKey("applist_search_hidden")
        val SORT_BY_USAGE = booleanPreferencesKey("sort_by_usage")
        val LAUNCH_COUNTS = stringPreferencesKey(PREF_LAUNCH_COUNTS)
        val EDGE_ZONE_WIDTH_DP = intPreferencesKey("edge_zone_width_dp")
        val EDGE_ZONE_INSET_DP = intPreferencesKey("edge_zone_inset_dp")
        val EDGE_ZONE_INSET_AUTO = booleanPreferencesKey("edge_zone_inset_auto")
        val QUICK_LAUNCH_LEFT = stringPreferencesKey(PREF_QUICK_LAUNCH_LEFT)
        val QUICK_LAUNCH_RIGHT = stringPreferencesKey(PREF_QUICK_LAUNCH_RIGHT)
        val LAYOUT_DEFAULTS_VERSION = intPreferencesKey("layout_defaults_version")
        val WELCOME_SEEN = booleanPreferencesKey("welcome_seen")
        val DIM_OTHERS_SCRUBBING = booleanPreferencesKey("dim_others_scrubbing")
        val MARK_WORK_APPS = booleanPreferencesKey("mark_work_apps")
        val TEXT_SHADOW = booleanPreferencesKey("text_shadow")
        val TEXT_SHADOW_STRENGTH = intPreferencesKey("text_shadow_strength")
        val COMPACT_TAP_AREA = booleanPreferencesKey("compact_tap_area")
        val STAY_AFTER_PRIVATE_UNLOCK = booleanPreferencesKey("stay_after_private_unlock")
        val PRIVATE_SPACE_SECTION = booleanPreferencesKey("private_space_section")
        val FOLDERS_IN_APP_LIST = booleanPreferencesKey("folders_in_app_list")
        val RECENT_SECTION = booleanPreferencesKey("recent_section")
        val RECENT_SECTION_COUNT = intPreferencesKey("recent_section_count")
        val SHOW_APP_ICONS = booleanPreferencesKey("show_app_icons")
        val SHOW_FAVORITE_ICONS = booleanPreferencesKey("show_favorite_icons")
        val FAVORITES_SOURCE = stringPreferencesKey("favorites_source")
        val FREQUENT_COUNT = intPreferencesKey("frequent_count")
        val SHOW_LIST_HEADERS = booleanPreferencesKey("show_list_headers")
        val NOTIFICATION_BADGES = booleanPreferencesKey("notification_badges")
        val NOTIFICATION_PREVIEWS = booleanPreferencesKey("notification_previews")
        val NOTIFICATION_TEXT_SP = intPreferencesKey("notification_text_sp")
        val NOTIFICATION_BADGE_COLOR = intPreferencesKey("notification_badge_color")
        val SECTION_TOP_PERCENT = intPreferencesKey("section_top_percent")
        val CLOSE_FOLDER_ON_LAUNCH = booleanPreferencesKey("close_folder_on_launch")
        val SHOW_SETTINGS_ROW = booleanPreferencesKey("show_settings_row")
        val CORNER_BUTTON_KEY = stringPreferencesKey("corner_button_key")
        val AUTO_KEYBOARD = booleanPreferencesKey("auto_keyboard")
        val LAST_LETTER_TO_LINE = booleanPreferencesKey("last_letter_to_line")
        val FAVORITES_EVER_SET = booleanPreferencesKey("favorites_ever_set")
        val EDGE_ZONE_BAND_ONLY = booleanPreferencesKey("edge_zone_band_only")
        val HOLD_SCROLL = booleanPreferencesKey("hold_scroll")
        val WEB_SEARCH_FALLBACK = booleanPreferencesKey("web_search_fallback")
        val SWIPE_UP_OPENS_SEARCH = booleanPreferencesKey("swipe_up_opens_search")
        val HOLD_SCROLL_SPEED = intPreferencesKey("hold_scroll_speed")
        val ALIGNMENT = stringPreferencesKey("alignment")
        val APPLIST_ALIGNMENT = stringPreferencesKey("applist_alignment")
        val ICON_SIDE = stringPreferencesKey("icon_side")
        val STATUS_BAR_PEEK_SECONDS = intPreferencesKey("status_bar_peek_seconds")
        val AZ_BAND_TOP_FRACTION = floatPreferencesKey("az_band_top_fraction")
        val AZ_BAND_HEIGHT_FRACTION = floatPreferencesKey("az_band_height_fraction")
    }

    /** Every padding a user can set by hand; their presence is what retires the first-run layout. */
    private val padKeys = listOf(
        Keys.NOW_PLAYING_PAD_TOP,
        Keys.NOW_PLAYING_PAD_BOTTOM,
        Keys.WIDGET_PAD_TOP,
        Keys.WIDGET_PAD_BOTTOM,
        Keys.FAVORITES_PAD_TOP,
        Keys.FAVORITES_PAD_BOTTOM,
    )

    private val data get() = context.dataStore.data

    /**
     * Every stored setting as JSON, for moving a set-up to another phone or keeping it.
     *
     * Written from the store itself rather than a list of keys kept alongside it, because a
     * list like that is only right until the next setting is added and nobody remembers it.
     * The type travels with each value, since JSON cannot tell 1 from 1L from 1.0f and the
     * store very much can.
     *
     * A custom font is a path into this app's own storage, so it points at nothing on another
     * phone; the font falls back to the default there until one is picked again.
     *
     * [privateSerial] is the private space's profile serial, when there is one, so its apps —
     * and how often they were opened — never leave the device in a file the user can save
     * anywhere. Passed in rather than looked up here because resolving it needs Android types
     * this class otherwise avoids; the caller already has it from the same read that decided
     * what to show on screen.
     */
    suspend fun exportJson(stripOtherProfiles: Boolean): ExportResult {
        val stored = data.first()
        val values = JSONObject()
        var omittedPrivateSpace = false
        stored.asMap().forEach { (key, rawValue) ->
            val value = stripPrivateSpaceFromExport(key.name, rawValue, stripOtherProfiles)
            if (value == null) {
                omittedPrivateSpace = true
                return@forEach
            }
            if (value != rawValue) omittedPrivateSpace = true
            val entry = JSONObject()
            when (value) {
                is Boolean -> entry.put("type", "boolean").put("value", value)
                is Int -> entry.put("type", "int").put("value", value)
                is Long -> entry.put("type", "long").put("value", value)
                is Float -> entry.put("type", "float").put("value", value.toDouble())
                is String -> entry.put("type", "string").put("value", value)
                is Set<*> -> entry.put("type", "stringSet")
                    .put("value", JSONArray().apply { value.forEach { put(it.toString()) } })
                else -> return@forEach
            }
            values.put(key.name, entry)
        }
        val json = JSONObject()
            .put("format", EXPORT_FORMAT)
            .put("app", "Victoria Launcher")
            .put("values", values)
            .toString(2)
        return ExportResult(json, omittedPrivateSpace)
    }

    /**
     * Replaces every setting with the ones in [text]. Returns false if it is not ours.
     *
     * Parsed fully before anything is written: a half-read file that had already cleared the
     * store would leave someone with neither their old set-up nor the one they were restoring.
     */
    suspend fun importJson(text: String): Boolean {
        val parsed = runCatching {
            val root = JSONObject(text)
            if (root.optInt("format") != EXPORT_FORMAT) return false
            val values = root.getJSONObject("values")
            buildList {
                values.keys().forEach { name ->
                    val entry = values.getJSONObject(name)
                    // Pair(...) rather than `to`: DataStore has an infix `to` of its own on
                    // Key, which builds a Preferences.Pair and not the one wanted here.
                    val pair: Pair<Preferences.Key<*>, Any> = when (entry.getString("type")) {
                        "boolean" -> Pair(booleanPreferencesKey(name), entry.getBoolean("value"))
                        "int" -> Pair(intPreferencesKey(name), entry.getInt("value"))
                        "long" -> Pair(longPreferencesKey(name), entry.getLong("value"))
                        "float" -> Pair(floatPreferencesKey(name), entry.getDouble("value").toFloat())
                        "string" -> Pair(stringPreferencesKey(name), entry.getString("value"))
                        "stringSet" -> {
                            val array = entry.getJSONArray("value")
                            Pair(
                                stringSetPreferencesKey(name),
                                (0 until array.length()).map { array.getString(it) }.toSet(),
                            )
                        }
                        else -> return@forEach
                    }
                    add(pair)
                }
            }
        }.getOrNull() ?: return false

        context.dataStore.edit { store ->
            store.clear()
            parsed.forEach { (key, value) ->
                @Suppress("UNCHECKED_CAST")
                store[key as Preferences.Key<Any>] = value
            }
        }
        return true
    }

    /** Favorites are stored as one newline-joined string; these are the only two readers. */
    private fun readFavorites(pref: Preferences): List<String> =
        pref[Keys.FAVORITES]?.split("\n")?.filter { it.isNotBlank() } ?: emptyList()

    private fun MutablePreferences.writeFavorites(list: List<String>) {
        this[Keys.FAVORITES] = list.joinToString("\n")
    }

    /**
     * Absent means this install predates multiple widgets, so the lone [Keys.WIDGET_ID] is
     * promoted. An empty string is different: it means every widget was removed, and must not
     * resurrect that old key.
     */
    private fun readWidgetIds(pref: Preferences): List<Int> {
        val raw = pref[Keys.WIDGET_IDS]
            ?: return listOfNotNull(pref[Keys.WIDGET_ID]?.takeIf { it > 0 })
        return raw.split(",").mapNotNull { it.trim().toIntOrNull() }.filter { it > 0 }
    }

    private fun MutablePreferences.writeWidgetIds(ids: List<Int>) {
        this[Keys.WIDGET_IDS] = ids.joinToString(",")
        // Mirrored so a downgrade to a single-widget build still finds one.
        this[Keys.WIDGET_ID] = ids.firstOrNull() ?: -1
    }

    val hiddenApps: Flow<Set<String>> =
        data.map { it[Keys.HIDDEN_APPS] ?: emptySet() }.distinctUntilChanged()

    val favorites: Flow<List<String>> =
        data.map { pref -> readFavorites(pref) }.distinctUntilChanged()

    val folders: Flow<List<Folder>> =
        data.map { pref -> foldersFromJson(pref[Keys.FOLDERS]) }.distinctUntilChanged()

    val nameOverrides: Flow<Map<String, String>> =
        data.map { pref -> jsonToMap(pref[Keys.NAME_OVERRIDES]) }.distinctUntilChanged()

    val iconOverrides: Flow<Map<String, String>> =
        data.map { pref -> jsonToMap(pref[Keys.ICON_OVERRIDES]) }.distinctUntilChanged()

    val iconSizeDp: Flow<Int> = data.map { it[Keys.ICON_SIZE_DP] ?: 56 }.distinctUntilChanged()

    val labelSizeSp: Flow<Int> = data.map { it[Keys.LABEL_SIZE_SP] ?: 16 }.distinctUntilChanged()

    /** Vertical gap between favorite rows. */
    val itemSpacingDp: Flow<Int> = data.map { it[Keys.ITEM_SPACING_DP] ?: 10 }.distinctUntilChanged()

    /** Left/right inset applied to every element on the home screen, so they stay in line. */
    val sidePaddingDp: Flow<Int> = data.map { it[Keys.SIDE_PADDING_DP] ?: 20 }.distinctUntilChanged()

    val nowPlayingHeightDp: Flow<Int> = data.map { it[Keys.NOW_PLAYING_HEIGHT_DP] ?: 64 }.distinctUntilChanged()

    /** Draggable top/bottom padding for each home block, set in edit mode. */
    val homePaddings: Flow<HomePaddings> = data.map {
        HomePaddings(
            nowPlayingTop = it[Keys.NOW_PLAYING_PAD_TOP] ?: 8,
            nowPlayingBottom = it[Keys.NOW_PLAYING_PAD_BOTTOM] ?: 8,
            widgetTop = it[Keys.WIDGET_PAD_TOP] ?: 8,
            widgetBottom = it[Keys.WIDGET_PAD_BOTTOM] ?: 8,
            favoritesTop = it[Keys.FAVORITES_PAD_TOP] ?: 8,
            favoritesBottom = it[Keys.FAVORITES_PAD_BOTTOM] ?: 24,
        )
    }.distinctUntilChanged()

    /** Absolute path of the typeface the user supplied, once it has been copied in. */
    val fontFile: Flow<String?> = data.map { it[Keys.FONT_FILE] }.distinctUntilChanged()

    /**
     * Whether swiping a row sideways offers the shortcuts its app publishes.
     *
     * On by default, since it is the quick way to reach them and the only one — they are not
     * in the long-press menu, which is for setting a row up rather than using it. Off is for
     * anyone who would rather their rows answered only to a tap.
     */
    /**
     * Falls back to the switch this replaced, so anyone who had turned it off stays off and
     * everyone else keeps the direction it always had.
     */
    val shortcutSwipe: Flow<ShortcutSwipe> =
        data.map { prefs ->
            prefs[Keys.SHORTCUT_SWIPE]
                ?.let { name -> runCatching { ShortcutSwipe.valueOf(name) }.getOrNull() }
                ?: if (prefs[Keys.SWIPE_FOR_SHORTCUTS] == false) ShortcutSwipe.OFF else ShortcutSwipe.RIGHT
        }.distinctUntilChanged()

    /**
     * Whether the launcher turns with the device.
     *
     * Null until it is set, which leaves the decision to the screen: a tablet has the height
     * for this sideways and a phone does not. Someone who wants it anyway — a phone in a car
     * mount is the case that came up — can say so.
     */
    val allowRotation: Flow<Boolean?> = data.map { it[Keys.ALLOW_ROTATION] }.distinctUntilChanged()

    /**
     * What the wallpaper is dimmed with, as an opaque RGB; the dim sliders set how much of it
     * lands. Black until the user picks otherwise, which is what it always was.
     */
    val dimColor: Flow<Int> =
        data.map { it[Keys.DIM_COLOR] ?: 0xFF000000.toInt() }.distinctUntilChanged()

    /** Used when the text color mode is CUSTOM. Opaque white until the user picks something. */
    val textColorCustom: Flow<Int> =
        data.map { it[Keys.TEXT_COLOR_CUSTOM] ?: 0xFFFFFFFF.toInt() }.distinctUntilChanged()

    /**
     * Draws the monochrome layer Android 13 added to adaptive icons, tinted to the system
     * palette, instead of the app's own colors. Apps that ship no such layer keep their
     * ordinary icon — there is nothing to derive one from.
     */
    val themedIcons: Flow<Boolean> = data.map { it[Keys.THEMED_ICONS] ?: false }.distinctUntilChanged()

    val iconShape: Flow<IconShape> = data.map { pref ->
        pref[Keys.ICON_SHAPE]?.let { runCatching { IconShape.valueOf(it) }.getOrNull() } ?: IconShape.SYSTEM
    }.distinctUntilChanged()

    val font: Flow<AppFont> = data.map {
        runCatching { AppFont.valueOf(it[Keys.FONT] ?: AppFont.SYSTEM.name) }.getOrDefault(AppFont.SYSTEM)
    }.distinctUntilChanged()

    val hideStatusBar: Flow<Boolean> = data.map { it[Keys.HIDE_STATUS_BAR] ?: false }.distinctUntilChanged()

    /**
     * The same choice for the app list, which used to follow the home screen's.
     *
     * Falls back to it until set, so nobody's status bar appears where it did not before.
     */
    val hideStatusBarAppList: Flow<Boolean> =
        data.map { it[Keys.HIDE_STATUS_BAR_APPLIST] ?: it[Keys.HIDE_STATUS_BAR] ?: false }
            .distinctUntilChanged()

    val dimWallpaperAlpha: Flow<Float> = data.map { it[Keys.DIM_WALLPAPER_ALPHA] ?: 0.35f }.distinctUntilChanged()

    val hapticsEnabled: Flow<Boolean> = data.map { it[Keys.HAPTICS_ENABLED] ?: true }.distinctUntilChanged()

    val dimHomeAlpha: Flow<Float> = data.map { it[Keys.DIM_HOME_ALPHA] ?: 0f }.distinctUntilChanged()

    val showFavoriteLabels: Flow<Boolean> =
        data.map { it[Keys.SHOW_FAVORITE_LABELS] ?: true }.distinctUntilChanged()

    val textColorMode: Flow<TextColorMode> = data.map {
        runCatching { TextColorMode.valueOf(it[Keys.TEXT_COLOR_MODE] ?: TextColorMode.AUTO.name) }
            .getOrDefault(TextColorMode.AUTO)
    }.distinctUntilChanged()

    val doubleTapToLock: Flow<Boolean> =
        data.map { it[Keys.DOUBLE_TAP_TO_LOCK] ?: false }.distinctUntilChanged()

    val edgeSide: Flow<EdgeSide> = data.map {
        runCatching { EdgeSide.valueOf(it[Keys.EDGE_SIDE] ?: EdgeSide.RIGHT.name) }.getOrDefault(EdgeSide.RIGHT)
    }.distinctUntilChanged()

    val scrubStyle: Flow<ScrubStyle> = data.map {
        runCatching { ScrubStyle.valueOf(it[Keys.SCRUB_STYLE] ?: ScrubStyle.BELL.name) }.getOrDefault(ScrubStyle.BELL)
    }.distinctUntilChanged()

    val scrubBubbleShape: Flow<ScrubBubbleShape> = data.map {
        runCatching { ScrubBubbleShape.valueOf(it[Keys.SCRUB_BUBBLE_SHAPE] ?: ScrubBubbleShape.ROUNDED.name) }
            .getOrDefault(ScrubBubbleShape.ROUNDED)
    }.distinctUntilChanged()

    val rippleParams: Flow<RippleParams> = data.map {
        val d = RippleParams()
        RippleParams(
            speed = (it[Keys.RIPPLE_SPEED] ?: d.speed).coerceIn(RippleParams.SPEED_RANGE),
            damping = (it[Keys.RIPPLE_DAMPING] ?: d.damping).coerceIn(RippleParams.DAMPING_RANGE),
            stiffness = (it[Keys.RIPPLE_STIFFNESS] ?: d.stiffness).coerceIn(RippleParams.STIFFNESS_RANGE),
        )
    }.distinctUntilChanged()

    /** Keep the A-Z strip on screen even when the app list is closed. */
    /**
     * When the strip sits on the home screen with no app list open.
     *
     * Reads the old on/off answer when this has not been set, so nobody's strip appears or
     * disappears on update. LANDSCAPE is for a phone in a car mount, where the strip earns
     * the room it takes and upright it does not.
     */
    val azStripVisibility: Flow<AzStripVisibility> = data.map { pref ->
        pref[Keys.AZ_STRIP_VISIBILITY]?.let { runCatching { AzStripVisibility.valueOf(it) }.getOrNull() }
            ?: if (pref[Keys.ALWAYS_SHOW_AZ] == true) AzStripVisibility.ALWAYS else AzStripVisibility.NEVER
    }.distinctUntilChanged()

    /** The A-Z strip inside the app list; the edge gesture still works without it. */
    val showAlphabet: Flow<Boolean> = data.map { it[Keys.SHOW_ALPHABET] ?: true }.distinctUntilChanged()

    /** Lay icons and labels out from the right edge instead of the left. */
    val alignRight: Flow<Boolean> = data.map { it[Keys.ALIGN_RIGHT] ?: false }.distinctUntilChanged()

    val iconPackPackage: Flow<String?> = data.map { it[Keys.ICON_PACK_PACKAGE] }.distinctUntilChanged()

    val nowPlayingEnabled: Flow<Boolean> = data.map { it[Keys.NOW_PLAYING_ENABLED] ?: false }.distinctUntilChanged()

    val widgetId: Flow<Int> = data.map { it[Keys.WIDGET_ID] ?: -1 }.distinctUntilChanged()
    /** Index into the merged (favorites + widget) home list where the widget sits. 0 = top. */
    val widgetPosition: Flow<Int> = data.map { it[Keys.WIDGET_POSITION] ?: 0 }.distinctUntilChanged()
    val widgetHeightDp: Flow<Int> = data.map { it[Keys.WIDGET_HEIGHT_DP] ?: 180 }.distinctUntilChanged()

    /** Home widgets one under another instead of swiped between (#128). */
    val widgetsStacked: Flow<Boolean> = data.map { it[Keys.WIDGETS_STACKED] ?: false }.distinctUntilChanged()

    suspend fun setWidgetsStacked(v: Boolean) {
        context.dataStore.edit { it[Keys.WIDGETS_STACKED] = v }
    }

    /** Victoria's own clock takes the height of what it is showing (#146). */
    val widgetHeightAuto: Flow<Boolean> = data.map { it[Keys.WIDGET_HEIGHT_AUTO] ?: false }.distinctUntilChanged()

    suspend fun setWidgetHeightAuto(v: Boolean) {
        context.dataStore.edit { it[Keys.WIDGET_HEIGHT_AUTO] = v }
    }

    val widgetIds: Flow<List<Int>> = data.map { readWidgetIds(it) }.distinctUntilChanged()

    /**
     * The widget's own left/right inset. Absent means it has never been set apart, so it
     * follows the favorites and nothing moves the first time this key appears.
     */
    val widgetSidePaddingDp: Flow<Int> =
        data.map { it[Keys.WIDGET_SIDE_PADDING_DP] ?: it[Keys.SIDE_PADDING_DP] ?: 20 }.distinctUntilChanged()

    /**
     * How far the widget is shifted sideways, negative left and positive right.
     *
     * A third-party widget lays out its own contents and most clocks center theirs, which
     * nothing out here can reach inside. Moving the whole widget is what moves them. Side
     * padding already sets how wide it is; this is only where that width sits.
     */
    val widgetOffsetXDp: Flow<Int> =
        data.map { (it[Keys.WIDGET_OFFSET_X_DP] ?: 0).coerceIn(-200, 200) }.distinctUntilChanged()

    /** Opening the app list by swiping up from the home screen. */
    val swipeUpOpensList: Flow<Boolean> =
        data.map { it[Keys.SWIPE_UP_OPENS_LIST] ?: false }.distinctUntilChanged()

    val appListSearchEnabled: Flow<Boolean> =
        data.map { it[Keys.APPLIST_SEARCH_ENABLED] ?: false }.distinctUntilChanged()

    /** Within thumb reach on a tall phone, rather than up by the status bar. */
    val appListSearchBottom: Flow<Boolean> =
        data.map { it[Keys.APPLIST_SEARCH_BOTTOM] ?: false }.distinctUntilChanged()

    /**
     * Lets a search reach apps hidden from the list.
     *
     * Off by default: hidden means hidden, and someone who hid an app did not ask for it back.
     */
    val appListSearchHidden: Flow<Boolean> =
        data.map { it[Keys.APPLIST_SEARCH_HIDDEN] ?: false }.distinctUntilChanged()

    /** Orders each letter's apps by how often they were opened from here, rather than by name. */
    val sortByUsage: Flow<Boolean> = data.map { it[Keys.SORT_BY_USAGE] ?: false }.distinctUntilChanged()

    val launchCounts: Flow<Map<String, Int>> = data.map { pref ->
        jsonToMap(pref[Keys.LAUNCH_COUNTS]).mapValues { (_, v) -> v.toIntOrNull() ?: 0 }
    }.distinctUntilChanged()

    /** Width of the invisible strip at each screen edge that opens the app list. */
    val edgeZoneWidthDp: Flow<Int> = data.map { it[Keys.EDGE_ZONE_WIDTH_DP] ?: 56 }.distinctUntilChanged()

    /**
     * How much of the very edge is left to the system rather than taken by the strip.
     *
     * Android's back gesture starts at the screen edge and so does this strip, so on a phone
     * with gesture navigation the two are reaching for the same pixels. Giving the outermost
     * few back means a swipe that starts right at the edge goes back and one that starts just
     * inside it scrubs.
     *
     * Zero by default: on a phone with buttons there is nothing to share with, and anyone the
     * conflict bothers can say so.
     */
    /**
     * Whether the room left for the back gesture follows the system's own gesture area.
     *
     * Android says exactly how far in from each edge its back gesture reaches, and says zero
     * when navigation is by buttons — so following it gives a phone with gesture navigation
     * the room it needs and changes nothing for one without. On unless someone has already
     * set the gap by hand, in which case their number stands.
     */
    val edgeZoneInsetAuto: Flow<Boolean> =
        data.map { it[Keys.EDGE_ZONE_INSET_AUTO] ?: (it[Keys.EDGE_ZONE_INSET_DP] == null) }
            .distinctUntilChanged()

    val edgeZoneInsetDp: Flow<Int> =
        data.map { (it[Keys.EDGE_ZONE_INSET_DP] ?: 0).coerceIn(EDGE_ZONE_INSET_RANGE) }
            .distinctUntilChanged()

    val quickLaunchLeft: Flow<String?> = data.map { it[Keys.QUICK_LAUNCH_LEFT] }.distinctUntilChanged()

    val quickLaunchRight: Flow<String?> = data.map { it[Keys.QUICK_LAUNCH_RIGHT] }.distinctUntilChanged()

    /** Drawing icons at all; off leaves text-only rows everywhere. */
    val showAppIcons: Flow<Boolean> = data.map { it[Keys.SHOW_APP_ICONS] ?: true }.distinctUntilChanged()

    /**
     * Falls back to the one switch these two were split out of, so anyone who had turned icons
     * off keeps them off in both places rather than having half of them come back.
     */
    val showFavoriteIcons: Flow<Boolean> =
        data.map { it[Keys.SHOW_FAVORITE_ICONS] ?: it[Keys.SHOW_APP_ICONS] ?: true }
            .distinctUntilChanged()

    /**
     * Apps kept out of the computed favorites, while still in the A-Z list.
     *
     * Hiding an app takes it out of everywhere, which is the wrong tool for an app you open
     * often and would rather not have a tap away. Only consulted while the favorites are the
     * computed ones; a manual list already says what is on it.
     */
    val frequentExcluded: Flow<Set<String>> =
        data.map { it[Keys.FREQUENT_EXCLUDED] ?: emptySet() }.distinctUntilChanged()

    val favoritesSource: Flow<FavoritesSource> =
        data.map { prefs ->
            prefs[Keys.FAVORITES_SOURCE]
                ?.let { name -> runCatching { FavoritesSource.valueOf(name) }.getOrNull() }
                ?: FavoritesSource.MANUAL
        }.distinctUntilChanged()

    /** How many of the most-opened apps the favorites section shows when it is computed. */
    val frequentCount: Flow<Int> =
        data.map { (it[Keys.FREQUENT_COUNT] ?: 6).coerceIn(FREQUENT_RANGE) }.distinctUntilChanged()

    val showListHeaders: Flow<Boolean> =
        data.map { it[Keys.SHOW_LIST_HEADERS] ?: true }.distinctUntilChanged()

    val notificationBadges: Flow<Boolean> =
        data.map { it[Keys.NOTIFICATION_BADGES] ?: false }.distinctUntilChanged()

    val notificationPreviews: Flow<Boolean> =
        data.map { it[Keys.NOTIFICATION_PREVIEWS] ?: false }.distinctUntilChanged()

    val notificationTextSp: Flow<Int> =
        data.map { it[Keys.NOTIFICATION_TEXT_SP] ?: 12 }.distinctUntilChanged()

    /** Null follows the theme's accent, which is what the count was drawn in before it could be chosen. */
    val notificationBadgeColor: Flow<Int?> =
        data.map { it[Keys.NOTIFICATION_BADGE_COLOR] }.distinctUntilChanged()

    /** How far down the screen a scrubbed letter is parked, as a percentage of the viewport. */
    val sectionTopPercent: Flow<Int> =
        data.map { (it[Keys.SECTION_TOP_PERCENT] ?: 26).coerceIn(SECTION_TOP_RANGE) }
            .distinctUntilChanged()

    /**
     * The app a button in the bottom corner opens, or null for no button at all.
     *
     * Null rather than a flag beside a key: there is nothing to draw without an app to draw it
     * for, so the two cannot disagree.
     */
    val cornerButtonKey: Flow<String?> = data.map { it[Keys.CORNER_BUTTON_KEY] }.distinctUntilChanged()

    /**
     * Whether opening the app list puts the cursor in the search box and the keyboard up.
     *
     * Off by default: the keyboard covers half of what was just opened, and most openings are
     * to look rather than to type.
     */
    val autoKeyboard: Flow<Boolean> =
        data.map { it[Keys.AUTO_KEYBOARD] ?: false }.distinctUntilChanged()

    /**
     * Whether the letters at the end of the list reach the same line as the rest.
     *
     * Off by default because the room they need is real: a screen's worth of empty space under
     * the last app, which is there whenever the list is open rather than only when it is used.
     */
    val lastLetterToLine: Flow<Boolean> =
        data.map { it[Keys.LAST_LETTER_TO_LINE] ?: true }.distinctUntilChanged()

    /**
     * Whether there has ever been a favorite on the home screen.
     *
     * The empty-favorites prompt is for someone who does not yet know how, and it had no way of
     * telling them from someone who knows exactly how and wants none — so a bare home screen by
     * choice carried the hint for good.
     */
    val favoritesEverSet: Flow<Boolean> =
        data.map { it[Keys.FAVORITES_EVER_SET] ?: false }.distinctUntilChanged()

    /**
     * Whether the edge that opens the app list is only as tall as the letters it shows.
     *
     * Off by default. The whole edge has always been live, and quietly taking that away is a
     * louder complaint than the one it answers — but on a home screen with a widget in reach of
     * the edge, a strip down the whole side is in the way of the widget.
     */
    val edgeZoneBandOnly: Flow<Boolean> =
        data.map { it[Keys.EDGE_ZONE_BAND_ONLY] ?: false }.distinctUntilChanged()

    /**
     * Whether a search that matches no app offers to hand the words to the browser.
     *
     * Off by default, and it is a row to tap rather than something that happens: typing in the
     * launcher does not reach a search engine because you stopped typing.
     */
    val webSearchFallback: Flow<Boolean> =
        data.map { it[Keys.WEB_SEARCH_FALLBACK] ?: false }.distinctUntilChanged()

    /** Whether swiping up puts the cursor in the search box rather than only opening the list. */
    val swipeUpOpensSearch: Flow<Boolean> =
        data.map { it[Keys.SWIPE_UP_OPENS_SEARCH] ?: false }.distinctUntilChanged()

    /**
     * Whether the private space's apps get a section of their own below the alphabet.
     *
     * Off by default. An app installed in both profiles has the same name in both, and only
     * someone who keeps a private space has any idea which of the two they are looking at.
     */
    val privateSpaceSection: Flow<Boolean> =
        data.map { it[Keys.PRIVATE_SPACE_SECTION] ?: false }.distinctUntilChanged()

    /** Whether folders also appear in the app list, filed under their own names (#126). */
    val foldersInAppList: Flow<Boolean> =
        data.map { it[Keys.FOLDERS_IN_APP_LIST] ?: false }.distinctUntilChanged()

    /** Whether the list ends with what was installed most recently. */
    val recentSection: Flow<Boolean> =
        data.map { it[Keys.RECENT_SECTION] ?: false }.distinctUntilChanged()

    /** How many of them. */
    val recentSectionCount: Flow<Int> =
        data.map { (it[Keys.RECENT_SECTION_COUNT] ?: 5).coerceIn(RECENT_SECTION_RANGE) }
            .distinctUntilChanged()

    /**
     * Whether unlocking the private space leaves the app list open.
     *
     * Off by default, as it always behaved: the list closes and the home screen comes back.
     * On, the list stays where the space's apps are about to appear.
     */
    val stayAfterPrivateUnlock: Flow<Boolean> =
        data.map { it[Keys.STAY_AFTER_PRIVATE_UNLOCK] ?: false }.distinctUntilChanged()

    /**
     * Whether a favorite answers a tap only on its icon and name.
     *
     * Off by default, which is how it always behaved: the whole line is the button. On, the
     * rest of the line is home screen again, for anyone opening apps they never meant to by
     * tapping beside a name.
     */
    val compactTapArea: Flow<Boolean> =
        data.map { it[Keys.COMPACT_TAP_AREA] ?: false }.distinctUntilChanged()

    /**
     * Whether launcher text carries a shadow, for reading it over a busy wallpaper.
     *
     * Only ever behind light text. A shadow under dark text on a light wallpaper muddies it
     * rather than separating it, so the setting asks for contrast and this decides where
     * contrast is actually gained.
     */
    val textShadow: Flow<Boolean> =
        data.map { it[Keys.TEXT_SHADOW] ?: false }.distinctUntilChanged()

    /** How strong that shadow is; the default is the look it shipped with. */
    val textShadowStrength: Flow<Int> =
        data.map { (it[Keys.TEXT_SHADOW_STRENGTH] ?: DEFAULT_SHADOW_STRENGTH).coerceIn(SHADOW_STRENGTH_RANGE) }
            .distinctUntilChanged()

    /**
     * Whether a work profile's apps say so after their name.
     *
     * On, since anyone with a work profile has two of several apps and no way to tell them
     * apart in a list of names. Nothing to see for anyone who has no second profile.
     */
    val markWorkApps: Flow<Boolean> =
        data.map { it[Keys.MARK_WORK_APPS] ?: true }.distinctUntilChanged()

    /**
     * Whether the rest of the list fades while a finger travels the alphabet.
     *
     * On, as it has always been — the fade is what makes the letter you are on findable. Off
     * for anyone who would rather keep sight of what is around it.
     */
    val dimOthersScrubbing: Flow<Boolean> =
        data.map { it[Keys.DIM_OTHERS_SCRUBBING] ?: true }.distinctUntilChanged()

    /** Whether resting a finger on a letter walks the list on through that letter's apps. */
    val holdScroll: Flow<Boolean> =
        data.map { it[Keys.HOLD_SCROLL] ?: false }.distinctUntilChanged()

    /** Rows a second while it does. */
    val holdScrollSpeed: Flow<Int> =
        data.map { (it[Keys.HOLD_SCROLL_SPEED] ?: 4).coerceIn(HOLD_SCROLL_RANGE) }
            .distinctUntilChanged()

    val showSettingsRow: Flow<Boolean> =
        data.map { it[Keys.SHOW_SETTINGS_ROW] ?: true }.distinctUntilChanged()

    val closeFolderOnLaunch: Flow<Boolean> =
        data.map { it[Keys.CLOSE_FOLDER_ON_LAUNCH] ?: false }.distinctUntilChanged()

    /**
     * Reads [key], falling back to the shared alignment and then to the old right-handed
     * boolean, so an upgrade keeps whichever side the user had chosen and splitting the two
     * lists apart starts them both where they already were.
     */
    private fun readAlignment(pref: Preferences, key: Preferences.Key<String>): HomeAlignment {
        val stored = pref[key] ?: pref[Keys.ALIGNMENT]
        return when {
            stored != null -> runCatching { HomeAlignment.valueOf(stored) }.getOrDefault(HomeAlignment.LEFT)
            pref[Keys.ALIGN_RIGHT] == true -> HomeAlignment.RIGHT
            else -> HomeAlignment.LEFT
        }
    }

    /** How the favorites on the home screen line up. */
    val alignment: Flow<HomeAlignment> =
        data.map { readAlignment(it, Keys.ALIGNMENT) }.distinctUntilChanged()

    /** How the A-Z list lines up, which people want to differ from the home screen. */
    val appListAlignment: Flow<HomeAlignment> =
        data.map { readAlignment(it, Keys.APPLIST_ALIGNMENT) }.distinctUntilChanged()

    val iconSide: Flow<IconSide> = data.map {
        runCatching { IconSide.valueOf(it[Keys.ICON_SIDE] ?: IconSide.LEFT.name) }
            .getOrDefault(IconSide.LEFT)
    }.distinctUntilChanged()

    /** How long a pull-down keeps the status bar on screen before it fades away again. */
    val statusBarPeekSeconds: Flow<Int> =
        data.map { it[Keys.STATUS_BAR_PEEK_SECONDS] ?: 5 }.distinctUntilChanged()

    /** Null while the A-Z strip follows the favorites; a set range is a fraction of the viewport. */
    val scrubBand: Flow<Pair<Float, Float>?> = data.map { pref ->
        val top = pref[Keys.AZ_BAND_TOP_FRACTION]
        val height = pref[Keys.AZ_BAND_HEIGHT_FRACTION]
        if (top != null && height != null) top to height else null
    }.distinctUntilChanged()

    /** 0 = installed before this scheme, 1 = a genuine first run. Absent until [ensureInstallMarker]. */
    val layoutDefaultsVersion: Flow<Int?> =
        data.map { it[Keys.LAYOUT_DEFAULTS_VERSION] }.distinctUntilChanged()

    val welcomeSeen: Flow<Boolean> = data.map { it[Keys.WELCOME_SEEN] ?: false }.distinctUntilChanged()

    /** True once any padding has been set by hand, which retires the computed first-run layout. */
    val hasCustomLayout: Flow<Boolean> =
        data.map { pref -> padKeys.any { pref.contains(it) } }.distinctUntilChanged()

    /**
     * Whether the favorites' own top gap has been set by hand.
     *
     * What retires the computed centred placement, rather than any layout padding at all.
     * Adjusting the gap *below* the favorites used to retire it too, which meant the centred
     * top had to be written out first to keep them where they were — and getting that wrong
     * sent them to the top of the screen with no obvious way back.
     */
    val hasCustomFavoritesTop: Flow<Boolean> =
        data.map { pref -> pref.contains(Keys.FAVORITES_PAD_TOP) }.distinctUntilChanged()

    suspend fun setHidden(componentKey: String, hidden: Boolean) {
        context.dataStore.edit { pref ->
            val current = pref[Keys.HIDDEN_APPS] ?: emptySet()
            pref[Keys.HIDDEN_APPS] = if (hidden) current + componentKey else current - componentKey
        }
    }

    suspend fun setFavorites(list: List<String>) {
        context.dataStore.edit { it.writeFavorites(list) }
    }

    suspend fun addFavorite(componentKey: String) {
        context.dataStore.edit { pref ->
            val current = readFavorites(pref)
            if (componentKey !in current) pref.writeFavorites(current + componentKey)
        }
    }

    suspend fun removeFavorite(componentKey: String) {
        context.dataStore.edit { pref ->
            pref.writeFavorites(readFavorites(pref) - componentKey)
        }
    }

    /**
     * Everything stored about one row, dropped in a single write. Only for a row that is gone
     * for good — a shortcut its publisher withdrew, which [AppRepository.unpin] calls once the
     * system itself has unpinned it. Never for a row that might merely be unreachable right
     * now: an app in a locked private space or a paused work profile also drops out of the
     * list, but its name, icon and place are still waiting when the profile comes back, so
     * unticking it in Manage Favorites only removes the favorite ([removeFavorite]), not this.
     *
     * A shortcut that has been unpinned does not come back, so what is kept under its key is
     * only clutter nothing can reach, and it would be restored onto a new phone by the settings
     * backup as well.
     *
     * One transaction rather than seven, so a row cannot end up half forgotten.
     */
    suspend fun forgetEntry(componentKey: String) {
        context.dataStore.edit { pref ->
            val favorites = readFavorites(pref)
            if (componentKey in favorites) pref.writeFavorites(favorites - componentKey)

            val folders = foldersFromJson(pref[Keys.FOLDERS])
            if (folders.any { componentKey in it.apps }) {
                pref[Keys.FOLDERS] = foldersToJson(folders.map { it.copy(apps = it.apps - componentKey) })
            }

            val names = jsonToMap(pref[Keys.NAME_OVERRIDES])
            if (componentKey in names) pref[Keys.NAME_OVERRIDES] = mapToJson(names - componentKey)

            val icons = jsonToMap(pref[Keys.ICON_OVERRIDES])
            if (componentKey in icons) pref[Keys.ICON_OVERRIDES] = mapToJson(icons - componentKey)

            val hidden = pref[Keys.HIDDEN_APPS] ?: emptySet()
            if (componentKey in hidden) pref[Keys.HIDDEN_APPS] = hidden - componentKey

            val counts = jsonToMap(pref[Keys.LAUNCH_COUNTS])
            if (componentKey in counts) pref[Keys.LAUNCH_COUNTS] = mapToJson(counts - componentKey)

            // A quick-launch slot that still points at this key would otherwise swipe to
            // nothing once the row is gone for good.
            if (pref[Keys.CORNER_BUTTON_KEY] == componentKey) pref.remove(Keys.CORNER_BUTTON_KEY)
            if (pref[Keys.QUICK_LAUNCH_LEFT] == componentKey) pref.remove(Keys.QUICK_LAUNCH_LEFT)
            if (pref[Keys.QUICK_LAUNCH_RIGHT] == componentKey) pref.remove(Keys.QUICK_LAUNCH_RIGHT)
        }
    }

    /** Creates the folder if [id] is new, otherwise replaces it. */
    suspend fun upsertFolder(folder: Folder) {
        context.dataStore.edit { pref ->
            val existing = foldersFromJson(pref[Keys.FOLDERS])
            val updated = if (existing.any { it.id == folder.id }) {
                existing.map { if (it.id == folder.id) folder else it }
            } else {
                existing + folder
            }
            pref[Keys.FOLDERS] = foldersToJson(updated)
        }
    }

    /** Removes the folder and its row; the apps themselves are untouched. */
    suspend fun deleteFolder(id: String) {
        context.dataStore.edit { pref ->
            pref[Keys.FOLDERS] = foldersToJson(foldersFromJson(pref[Keys.FOLDERS]).filterNot { it.id == id })
            pref.writeFavorites(readFavorites(pref).filterNot { it == folderToken(id) })
        }
    }

    suspend fun setFolderIcon(id: String, icon: String?) {
        context.dataStore.edit { pref ->
            val updated = foldersFromJson(pref[Keys.FOLDERS])
                .map { if (it.id == id) it.copy(icon = icon) else it }
            pref[Keys.FOLDERS] = foldersToJson(updated)
        }
    }

    suspend fun setFolderApps(id: String, apps: List<String>) {
        context.dataStore.edit { pref ->
            val updated = foldersFromJson(pref[Keys.FOLDERS])
                .map { if (it.id == id) it.copy(apps = apps) else it }
            pref[Keys.FOLDERS] = foldersToJson(updated)
        }
    }

    /**
     * Puts [componentKey] in the folder. An app that was a top-level favorite moves into it
     * rather than being duplicated in both places.
     */
    suspend fun addAppToFolder(folderId: String, componentKey: String) {
        context.dataStore.edit { pref ->
            val updated = foldersFromJson(pref[Keys.FOLDERS]).map { folder ->
                if (folder.id == folderId && componentKey !in folder.apps) {
                    folder.copy(apps = folder.apps + componentKey)
                } else {
                    folder
                }
            }
            pref[Keys.FOLDERS] = foldersToJson(updated)
            pref.writeFavorites(readFavorites(pref).filterNot { it == componentKey })
        }
    }

    /** Changes one folder in place, leaving the rest of the list as it was. */
    private suspend fun updateFolder(folderId: String, change: (Folder) -> Folder) {
        context.dataStore.edit { pref ->
            val updated = foldersFromJson(pref[Keys.FOLDERS]).map { if (it.id == folderId) change(it) else it }
            pref[Keys.FOLDERS] = foldersToJson(updated)
        }
    }

    suspend fun setFolderNowPlaying(folderId: String, on: Boolean) = updateFolder(folderId) {
        it.copy(nowPlaying = on)
    }

    suspend fun addFolderWidget(folderId: String, widgetId: Int) = updateFolder(folderId) {
        it.copy(widgets = it.widgets + FolderWidget(widgetId, FOLDER_WIDGET_DEFAULT_HEIGHT_DP))
    }

    suspend fun removeFolderWidget(folderId: String, widgetId: Int) = updateFolder(folderId) {
        it.copy(widgets = it.widgets.filterNot { w -> w.id == widgetId })
    }

    suspend fun setFolderWidgetHeight(folderId: String, widgetId: Int, heightDp: Int) = updateFolder(folderId) {
        it.copy(widgets = it.widgets.map { w -> if (w.id == widgetId) w.copy(heightDp = heightDp) else w })
    }

    suspend fun removeAppFromFolder(folderId: String, componentKey: String) {
        context.dataStore.edit { pref ->
            val updated = foldersFromJson(pref[Keys.FOLDERS]).map { folder ->
                if (folder.id == folderId) folder.copy(apps = folder.apps - componentKey) else folder
            }
            pref[Keys.FOLDERS] = foldersToJson(updated)
        }
    }

    suspend fun setNameOverride(componentKey: String, name: String?) {
        context.dataStore.edit { pref ->
            val map = jsonToMap(pref[Keys.NAME_OVERRIDES]).toMutableMap()
            if (name.isNullOrBlank()) map.remove(componentKey) else map[componentKey] = name
            pref[Keys.NAME_OVERRIDES] = mapToJson(map)
        }
    }

    suspend fun setIconOverride(componentKey: String, uri: String?) {
        context.dataStore.edit { pref ->
            val map = jsonToMap(pref[Keys.ICON_OVERRIDES]).toMutableMap()
            if (uri.isNullOrBlank()) map.remove(componentKey) else map[componentKey] = uri
            pref[Keys.ICON_OVERRIDES] = mapToJson(map)
        }
    }

    suspend fun setIconSizeDp(v: Int) {
        context.dataStore.edit { it[Keys.ICON_SIZE_DP] = v }
    }

    suspend fun setLabelSizeSp(v: Int) {
        context.dataStore.edit { it[Keys.LABEL_SIZE_SP] = v }
    }

    suspend fun setSidePaddingDp(v: Int) {
        context.dataStore.edit { it[Keys.SIDE_PADDING_DP] = v }
    }

    suspend fun setItemSpacingDp(v: Int) {
        context.dataStore.edit { it[Keys.ITEM_SPACING_DP] = v }
    }

    suspend fun setNowPlayingHeightDp(v: Int) {
        context.dataStore.edit { it[Keys.NOW_PLAYING_HEIGHT_DP] = v }
    }

    suspend fun setHomePadding(slot: PaddingSlot, v: Int) {
        val key = when (slot) {
            PaddingSlot.NOW_PLAYING_TOP -> Keys.NOW_PLAYING_PAD_TOP
            PaddingSlot.NOW_PLAYING_BOTTOM -> Keys.NOW_PLAYING_PAD_BOTTOM
            PaddingSlot.WIDGET_TOP -> Keys.WIDGET_PAD_TOP
            PaddingSlot.WIDGET_BOTTOM -> Keys.WIDGET_PAD_BOTTOM
            PaddingSlot.FAVORITES_TOP -> Keys.FAVORITES_PAD_TOP
            PaddingSlot.FAVORITES_BOTTOM -> Keys.FAVORITES_PAD_BOTTOM
        }
        context.dataStore.edit { it[key] = v }
    }

    suspend fun setFontFile(path: String?) {
        context.dataStore.edit { pref ->
            if (path == null) pref.remove(Keys.FONT_FILE) else pref[Keys.FONT_FILE] = path
        }
    }

    suspend fun setShortcutSwipe(v: ShortcutSwipe) {
        context.dataStore.edit {
            it[Keys.SHORTCUT_SWIPE] = v.name
            // Mirrored, so a downgrade to the version that only had a switch reads it right.
            it[Keys.SWIPE_FOR_SHORTCUTS] = v != ShortcutSwipe.OFF
        }
    }

    suspend fun setAllowRotation(v: Boolean) {
        context.dataStore.edit { it[Keys.ALLOW_ROTATION] = v }
    }

    suspend fun setDimColor(argb: Int) {
        context.dataStore.edit { it[Keys.DIM_COLOR] = argb }
    }

    suspend fun setTextColorCustom(argb: Int) {
        context.dataStore.edit { it[Keys.TEXT_COLOR_CUSTOM] = argb }
    }

    suspend fun setThemedIcons(v: Boolean) {
        context.dataStore.edit { it[Keys.THEMED_ICONS] = v }
    }

    suspend fun setIconShape(v: IconShape) {
        context.dataStore.edit { it[Keys.ICON_SHAPE] = v.name }
    }

    suspend fun setFont(f: AppFont) {
        context.dataStore.edit { it[Keys.FONT] = f.name }
    }

    suspend fun setHideStatusBarAppList(v: Boolean) {
        context.dataStore.edit { it[Keys.HIDE_STATUS_BAR_APPLIST] = v }
    }

    suspend fun setHideStatusBar(v: Boolean) {
        context.dataStore.edit { it[Keys.HIDE_STATUS_BAR] = v }
    }

    suspend fun setDimWallpaperAlpha(v: Float) {
        context.dataStore.edit { it[Keys.DIM_WALLPAPER_ALPHA] = v }
    }

    suspend fun setDimHomeAlpha(v: Float) {
        context.dataStore.edit { it[Keys.DIM_HOME_ALPHA] = v }
    }

    suspend fun setShowFavoriteLabels(v: Boolean) {
        context.dataStore.edit { it[Keys.SHOW_FAVORITE_LABELS] = v }
    }

    suspend fun setTextColorMode(v: TextColorMode) {
        context.dataStore.edit { it[Keys.TEXT_COLOR_MODE] = v.name }
    }

    suspend fun setDoubleTapToLock(v: Boolean) {
        context.dataStore.edit { it[Keys.DOUBLE_TAP_TO_LOCK] = v }
    }

    suspend fun setHapticsEnabled(v: Boolean) {
        context.dataStore.edit { it[Keys.HAPTICS_ENABLED] = v }
    }

    suspend fun setShowAlphabet(v: Boolean) {
        context.dataStore.edit { it[Keys.SHOW_ALPHABET] = v }
    }

    suspend fun setAlignRight(v: Boolean) {
        context.dataStore.edit { it[Keys.ALIGN_RIGHT] = v }
    }

    suspend fun setAzStripVisibility(v: AzStripVisibility) {
        context.dataStore.edit {
            it[Keys.AZ_STRIP_VISIBILITY] = v.name
            // Kept in step so an older build reads something sensible if one is installed.
            it[Keys.ALWAYS_SHOW_AZ] = v == AzStripVisibility.ALWAYS
        }
    }

    suspend fun setEdgeSide(v: EdgeSide) {
        context.dataStore.edit { it[Keys.EDGE_SIDE] = v.name }
    }

    suspend fun setRippleParams(v: RippleParams) {
        context.dataStore.edit {
            it[Keys.RIPPLE_SPEED] = v.speed
            it[Keys.RIPPLE_DAMPING] = v.damping
            it[Keys.RIPPLE_STIFFNESS] = v.stiffness
        }
    }

    suspend fun setScrubStyle(v: ScrubStyle) {
        context.dataStore.edit { it[Keys.SCRUB_STYLE] = v.name }
    }

    suspend fun setScrubBubbleShape(v: ScrubBubbleShape) {
        context.dataStore.edit { it[Keys.SCRUB_BUBBLE_SHAPE] = v.name }
    }

    suspend fun setIconPackPackage(pkg: String?) {
        context.dataStore.edit { pref ->
            if (pkg.isNullOrBlank()) pref.remove(Keys.ICON_PACK_PACKAGE) else pref[Keys.ICON_PACK_PACKAGE] = pkg
        }
    }

    suspend fun setWidgetId(id: Int) {
        context.dataStore.edit { it[Keys.WIDGET_ID] = id }
    }

    suspend fun setNowPlayingEnabled(v: Boolean) {
        context.dataStore.edit { it[Keys.NOW_PLAYING_ENABLED] = v }
    }

    suspend fun setWidgetPosition(v: Int) {
        context.dataStore.edit { it[Keys.WIDGET_POSITION] = v }
    }

    suspend fun setWidgetHeightDp(v: Int) {
        context.dataStore.edit { it[Keys.WIDGET_HEIGHT_DP] = v }
    }

    suspend fun addWidgetId(id: Int) {
        context.dataStore.edit { pref ->
            val current = readWidgetIds(pref)
            if (id !in current) pref.writeWidgetIds(current + id)
        }
    }

    suspend fun removeWidgetId(id: Int) {
        context.dataStore.edit { pref -> pref.writeWidgetIds(readWidgetIds(pref) - id) }
    }

    suspend fun setWidgetSidePaddingDp(v: Int) {
        context.dataStore.edit { it[Keys.WIDGET_SIDE_PADDING_DP] = v }
    }

    suspend fun setWidgetOffsetXDp(v: Int) {
        context.dataStore.edit { it[Keys.WIDGET_OFFSET_X_DP] = v.coerceIn(-200, 200) }
    }

    suspend fun setSwipeUpOpensList(v: Boolean) {
        context.dataStore.edit { it[Keys.SWIPE_UP_OPENS_LIST] = v }
    }

    suspend fun setAppListSearchEnabled(v: Boolean) {
        context.dataStore.edit { it[Keys.APPLIST_SEARCH_ENABLED] = v }
    }

    suspend fun setAppListSearchBottom(v: Boolean) {
        context.dataStore.edit { it[Keys.APPLIST_SEARCH_BOTTOM] = v }
    }

    suspend fun setAppListSearchHidden(v: Boolean) {
        context.dataStore.edit { it[Keys.APPLIST_SEARCH_HIDDEN] = v }
    }

    suspend fun setSortByUsage(v: Boolean) {
        context.dataStore.edit { it[Keys.SORT_BY_USAGE] = v }
    }

    /**
     * Counted for every launch, not just while the usage sort is on, so turning the sort on
     * later has a history to order by rather than starting from nothing.
     */
    suspend fun incrementLaunchCount(componentKey: String) {
        context.dataStore.edit { pref ->
            val map = jsonToMap(pref[Keys.LAUNCH_COUNTS]).toMutableMap()
            map[componentKey] = ((map[componentKey]?.toIntOrNull() ?: 0) + 1).toString()
            pref[Keys.LAUNCH_COUNTS] = mapToJson(map)
        }
    }

    suspend fun setEdgeZoneWidthDp(v: Int) {
        context.dataStore.edit { it[Keys.EDGE_ZONE_WIDTH_DP] = v }
    }

    suspend fun setQuickLaunch(slot: QuickLaunchSlot, componentKey: String?) {
        val key = when (slot) {
            QuickLaunchSlot.LEFT -> Keys.QUICK_LAUNCH_LEFT
            QuickLaunchSlot.RIGHT -> Keys.QUICK_LAUNCH_RIGHT
        }
        context.dataStore.edit { pref ->
            if (componentKey.isNullOrBlank()) pref.remove(key) else pref[key] = componentKey
        }
    }

    suspend fun setShowAppIcons(v: Boolean) {
        context.dataStore.edit { it[Keys.SHOW_APP_ICONS] = v }
    }

    suspend fun setShowFavoriteIcons(v: Boolean) {
        context.dataStore.edit { it[Keys.SHOW_FAVORITE_ICONS] = v }
    }

    suspend fun setFavoritesSource(v: FavoritesSource) {
        context.dataStore.edit { it[Keys.FAVORITES_SOURCE] = v.name }
    }

    suspend fun setFrequentCount(v: Int) {
        context.dataStore.edit { it[Keys.FREQUENT_COUNT] = v.coerceIn(FREQUENT_RANGE) }
    }

    suspend fun setShowListHeaders(v: Boolean) {
        context.dataStore.edit { it[Keys.SHOW_LIST_HEADERS] = v }
    }

    suspend fun setNotificationBadges(v: Boolean) {
        context.dataStore.edit { it[Keys.NOTIFICATION_BADGES] = v }
    }

    suspend fun setNotificationPreviews(v: Boolean) {
        context.dataStore.edit { it[Keys.NOTIFICATION_PREVIEWS] = v }
    }

    suspend fun setNotificationTextSp(v: Int) {
        context.dataStore.edit { it[Keys.NOTIFICATION_TEXT_SP] = v }
    }

    suspend fun setNotificationBadgeColor(argb: Int?) {
        context.dataStore.edit {
            if (argb == null) it.remove(Keys.NOTIFICATION_BADGE_COLOR) else it[Keys.NOTIFICATION_BADGE_COLOR] = argb
        }
    }

    suspend fun setSectionTopPercent(v: Int) {
        context.dataStore.edit { it[Keys.SECTION_TOP_PERCENT] = v.coerceIn(SECTION_TOP_RANGE) }
    }

    suspend fun setCornerButton(componentKey: String?) {
        context.dataStore.edit { pref ->
            if (componentKey.isNullOrBlank()) pref.remove(Keys.CORNER_BUTTON_KEY)
            else pref[Keys.CORNER_BUTTON_KEY] = componentKey
        }
    }

    suspend fun setLastLetterToLine(v: Boolean) {
        context.dataStore.edit { it[Keys.LAST_LETTER_TO_LINE] = v }
    }

    suspend fun setAutoKeyboard(v: Boolean) {
        context.dataStore.edit { it[Keys.AUTO_KEYBOARD] = v }
    }

    suspend fun setWebSearchFallback(v: Boolean) {
        context.dataStore.edit { it[Keys.WEB_SEARCH_FALLBACK] = v }
    }

    suspend fun setSwipeUpOpensSearch(v: Boolean) {
        context.dataStore.edit { it[Keys.SWIPE_UP_OPENS_SEARCH] = v }
    }

    /**
     * Settings a fresh install should start with, which an existing one must not be given.
     *
     * Some defaults are only right for someone who has not used this before. Confining the live
     * edge to the letters is the better first experience; changing it under someone who has
     * been swiping the whole side for months is not an improvement, it is their launcher
     * behaving differently one morning. So it is written once, when the welcome is dismissed —
     * a screen only a new install ever sees — and only where nothing has been chosen already.
     */
    suspend fun applyNewInstallDefaults() {
        context.dataStore.edit {
            if (it[Keys.EDGE_ZONE_BAND_ONLY] == null) it[Keys.EDGE_ZONE_BAND_ONLY] = true
        }
    }

    suspend fun setEdgeZoneInsetAuto(v: Boolean) {
        context.dataStore.edit { it[Keys.EDGE_ZONE_INSET_AUTO] = v }
    }

    suspend fun setEdgeZoneInsetDp(v: Int) {
        context.dataStore.edit { it[Keys.EDGE_ZONE_INSET_DP] = v.coerceIn(EDGE_ZONE_INSET_RANGE) }
    }

    suspend fun setFrequentExcluded(key: String, excluded: Boolean) {
        context.dataStore.edit { prefs ->
            val current = prefs[Keys.FREQUENT_EXCLUDED] ?: emptySet()
            prefs[Keys.FREQUENT_EXCLUDED] =
                if (excluded) current + key else current - key
        }
    }

    suspend fun setPrivateSpaceSection(v: Boolean) {
        context.dataStore.edit { it[Keys.PRIVATE_SPACE_SECTION] = v }
    }

    suspend fun setFoldersInAppList(v: Boolean) {
        context.dataStore.edit { it[Keys.FOLDERS_IN_APP_LIST] = v }
    }

    suspend fun setRecentSection(v: Boolean) {
        context.dataStore.edit { it[Keys.RECENT_SECTION] = v }
    }

    suspend fun setRecentSectionCount(v: Int) {
        context.dataStore.edit { it[Keys.RECENT_SECTION_COUNT] = v.coerceIn(RECENT_SECTION_RANGE) }
    }

    suspend fun setStayAfterPrivateUnlock(v: Boolean) {
        context.dataStore.edit { it[Keys.STAY_AFTER_PRIVATE_UNLOCK] = v }
    }

    suspend fun setCompactTapArea(v: Boolean) {
        context.dataStore.edit { it[Keys.COMPACT_TAP_AREA] = v }
    }

    suspend fun setTextShadowStrength(v: Int) {
        context.dataStore.edit { it[Keys.TEXT_SHADOW_STRENGTH] = v.coerceIn(SHADOW_STRENGTH_RANGE) }
    }

    suspend fun setTextShadow(v: Boolean) {
        context.dataStore.edit { it[Keys.TEXT_SHADOW] = v }
    }

    suspend fun setMarkWorkApps(v: Boolean) {
        context.dataStore.edit { it[Keys.MARK_WORK_APPS] = v }
    }

    suspend fun setDimOthersScrubbing(v: Boolean) {
        context.dataStore.edit { it[Keys.DIM_OTHERS_SCRUBBING] = v }
    }

    suspend fun setHoldScroll(v: Boolean) {
        context.dataStore.edit { it[Keys.HOLD_SCROLL] = v }
    }

    suspend fun setHoldScrollSpeed(v: Int) {
        context.dataStore.edit { it[Keys.HOLD_SCROLL_SPEED] = v.coerceIn(HOLD_SCROLL_RANGE) }
    }

    suspend fun setEdgeZoneBandOnly(v: Boolean) {
        context.dataStore.edit { it[Keys.EDGE_ZONE_BAND_ONLY] = v }
    }

    suspend fun markFavoritesEverSet() {
        context.dataStore.edit {
            if (it[Keys.FAVORITES_EVER_SET] != true) it[Keys.FAVORITES_EVER_SET] = true
        }
    }

    suspend fun setShowSettingsRow(v: Boolean) {
        context.dataStore.edit { it[Keys.SHOW_SETTINGS_ROW] = v }
    }

    suspend fun setCloseFolderOnLaunch(v: Boolean) {
        context.dataStore.edit { it[Keys.CLOSE_FOLDER_ON_LAUNCH] = v }
    }

    suspend fun setAlignment(v: HomeAlignment) {
        context.dataStore.edit {
            it[Keys.ALIGNMENT] = v.name
            // Kept in step so a downgrade still lands on the side the user picked.
            it[Keys.ALIGN_RIGHT] = v == HomeAlignment.RIGHT
        }
    }

    suspend fun setAppListAlignment(v: HomeAlignment) {
        context.dataStore.edit { it[Keys.APPLIST_ALIGNMENT] = v.name }
    }

    suspend fun setIconSide(v: IconSide) {
        context.dataStore.edit { it[Keys.ICON_SIDE] = v.name }
    }

    suspend fun setStatusBarPeekSeconds(v: Int) {
        context.dataStore.edit { it[Keys.STATUS_BAR_PEEK_SECONDS] = v }
    }

    suspend fun setScrubBand(topFraction: Float, heightFraction: Float) {
        context.dataStore.edit {
            it[Keys.AZ_BAND_TOP_FRACTION] = topFraction
            it[Keys.AZ_BAND_HEIGHT_FRACTION] = heightFraction
        }
    }

    /** Hands the strip back to following the favorites list. */
    suspend fun clearScrubBand() {
        context.dataStore.edit {
            it.remove(Keys.AZ_BAND_TOP_FRACTION)
            it.remove(Keys.AZ_BAND_HEIGHT_FRACTION)
        }
    }

    suspend fun setWelcomeSeen(v: Boolean) {
        context.dataStore.edit { it[Keys.WELCOME_SEEN] = v }
    }

    /**
     * Stamps whether this install is new, once. Nothing writes to the store before the user
     * changes something, so an empty store is the one reliable signal of a first run — which
     * is why this has to run before any other setter can muddy it.
     */
    suspend fun ensureInstallMarker() {
        context.dataStore.edit { pref ->
            if (pref[Keys.LAYOUT_DEFAULTS_VERSION] == null) {
                pref[Keys.LAYOUT_DEFAULTS_VERSION] = if (pref.asMap().isEmpty()) 1 else 0
            }
        }
    }

    private fun jsonToMap(json: String?): Map<String, String> {
        if (json.isNullOrBlank()) return emptyMap()
        return try {
            val obj = JSONObject(json)
            val map = mutableMapOf<String, String>()
            obj.keys().forEach { k -> map[k] = obj.getString(k) }
            map
        } catch (e: Exception) {
            emptyMap()
        }
    }

    private fun mapToJson(map: Map<String, String>): String {
        val obj = JSONObject()
        map.forEach { (k, v) -> obj.put(k, v) }
        return obj.toString()
    }
}